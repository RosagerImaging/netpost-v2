import { useState } from 'react';
import { 
  LayoutDashboard, 
  Package, 
  Bot, 
  Globe, 
  Settings, 
  Menu, 
  X,
  User
} from 'lucide-react';
import { cn } from '../ui/utils';

interface NavigationItem {
  name: string;
  href: string;
  icon: React.ElementType;
  current?: boolean;
}

const navigation: NavigationItem[] = [
  { name: 'Dashboard', href: '#', icon: LayoutDashboard, current: true },
  { name: 'Inventory', href: '#', icon: Package },
  { name: 'AI Assistant', href: '#', icon: Bot },
  { name: 'Marketplace Integrations', href: '#', icon: Globe },
  { name: 'Settings', href: '#', icon: Settings },
];

export function Sidebar() {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  return (
    <>
      {/* Mobile menu button */}
      <div className="lg:hidden fixed top-4 left-4 z-50">
        <button
          onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          className="p-2 rounded-lg bg-[#1C1C1E] text-[#8E8E93] hover:text-[#00BFFF] hover:bg-[#00BFFF]/10 transition-colors"
        >
          {isMobileMenuOpen ? (
            <X className="h-6 w-6" />
          ) : (
            <Menu className="h-6 w-6" />
          )}
        </button>
      </div>

      {/* Mobile backdrop */}
      {isMobileMenuOpen && (
        <div 
          className="lg:hidden fixed inset-0 bg-black/50 z-40"
          onClick={() => setIsMobileMenuOpen(false)}
        />
      )}

      {/* Sidebar */}
      <div className={cn(
        "fixed inset-y-0 left-0 z-40 w-[280px] bg-[#1C1C1E] border-r border-[#2C2C2E] flex flex-col transition-transform duration-300 ease-in-out",
        "lg:translate-x-0 lg:static lg:inset-0",
        isMobileMenuOpen ? "translate-x-0" : "-translate-x-full lg:translate-x-0"
      )}>
        {/* Logo/App Name */}
        <div className="flex items-center px-6 py-8 lg:py-8 pt-16">
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 bg-[#00BFFF] rounded-lg flex items-center justify-center">
              <Bot className="h-5 w-5 text-white" />
            </div>
            <div>
              <h1 className="text-[#E5E5E5] font-inter font-medium">AI-Native</h1>
              <p className="text-[#8E8E93] text-sm font-inter">Reselling Assistant</p>
            </div>
          </div>
        </div>

        {/* Navigation */}
        <nav className="flex-1 px-4 space-y-2">
          {navigation.map((item) => {
            const Icon = item.icon;
            return (
              <a
                key={item.name}
                href={item.href}
                className={cn(
                  "group flex items-center px-4 py-3 rounded-lg font-inter text-sm transition-all duration-200",
                  item.current
                    ? "bg-[#00BFFF]/10 text-[#00BFFF] shadow-[0_0_20px_rgba(0,191,255,0.3)]"
                    : "text-[#8E8E93] hover:text-[#00BFFF] hover:bg-[#00BFFF]/10 hover:shadow-[0_0_20px_rgba(0,191,255,0.2)]"
                )}
                onClick={() => setIsMobileMenuOpen(false)}
              >
                <Icon className="mr-3 h-5 w-5 flex-shrink-0" />
                {item.name}
              </a>
            );
          })}
        </nav>

        {/* User Section */}
        <div className="p-4 border-t border-[#2C2C2E]">
          <a
            href="#"
            className="flex items-center px-4 py-3 rounded-lg hover:bg-[#00BFFF]/10 hover:text-[#00BFFF] text-[#8E8E93] transition-all duration-200 group"
            onClick={() => setIsMobileMenuOpen(false)}
          >
            <div className="w-8 h-8 bg-[#FFD700] rounded-full flex items-center justify-center mr-3">
              <User className="h-4 w-4 text-[#111111]" />
            </div>
            <div className="min-w-0 flex-1">
              <p className="font-inter text-sm truncate">John Doe</p>
              <p className="font-inter text-xs text-[#6E6E73] group-hover:text-[#8E8E93] transition-colors">Account Settings</p>
            </div>
          </a>
        </div>
      </div>
    </>
  );
}