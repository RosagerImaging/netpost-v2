import { Sidebar } from './components/shared/Sidebar';

export default function App() {
  return (
    <div className="min-h-screen bg-[#111111] font-inter">
      <div className="flex">
        {/* Sidebar */}
        <Sidebar />
        
        {/* Main Content */}
        <main className="flex-1 lg:ml-0 min-h-screen">
          {/* Content Area */}
          <div className="pl-16 pr-8 py-8 lg:p-12">
            {/* Dashboard Placeholder */}
            <div className="max-w-7xl mx-auto">
              <div className="mb-8">
                <h1 className="text-3xl text-[#E5E5E5] font-inter font-medium mb-2">
                  Dashboard
                </h1>
                <p className="text-[#8E8E93] font-inter">
                  Welcome to your AI-Native Reselling Assistant
                </p>
              </div>
              
              {/* Placeholder Content Cards */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
                <div className="bg-[#1C1C1E] border border-[#2C2C2E] rounded-lg p-6">
                  <h3 className="text-[#E5E5E5] font-inter font-medium mb-2">
                    Total Revenue
                  </h3>
                  <p className="text-2xl text-[#00BFFF] font-inter font-medium">
                    $12,345
                  </p>
                  <p className="text-[#8E8E93] text-sm font-inter mt-1">
                    +12% from last month
                  </p>
                </div>
                
                <div className="bg-[#1C1C1E] border border-[#2C2C2E] rounded-lg p-6">
                  <h3 className="text-[#E5E5E5] font-inter font-medium mb-2">
                    Active Listings
                  </h3>
                  <p className="text-2xl text-[#FFD700] font-inter font-medium">
                    247
                  </p>
                  <p className="text-[#8E8E93] text-sm font-inter mt-1">
                    Across 3 platforms
                  </p>
                </div>
                
                <div className="bg-[#1C1C1E] border border-[#2C2C2E] rounded-lg p-6">
                  <h3 className="text-[#E5E5E5] font-inter font-medium mb-2">
                    AI Recommendations
                  </h3>
                  <p className="text-2xl text-[#E5E5E5] font-inter font-medium">
                    18
                  </p>
                  <p className="text-[#8E8E93] text-sm font-inter mt-1">
                    New opportunities found
                  </p>
                </div>
              </div>
              
              {/* Placeholder for Future Content */}
              <div className="bg-[#1C1C1E] border border-[#2C2C2E] rounded-lg p-8">
                <h2 className="text-xl text-[#E5E5E5] font-inter font-medium mb-4">
                  Recent Activity
                </h2>
                <div className="space-y-4">
                  {[1, 2, 3].map((item) => (
                    <div key={item} className="flex items-center justify-between p-4 bg-[#111111] rounded-lg">
                      <div>
                        <p className="text-[#E5E5E5] font-inter">
                          Sample activity item {item}
                        </p>
                        <p className="text-[#8E8E93] text-sm font-inter">
                          2 hours ago
                        </p>
                      </div>
                      <div className="text-[#00BFFF] font-inter text-sm">
                        View Details
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}