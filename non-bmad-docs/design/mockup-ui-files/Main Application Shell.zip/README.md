
  # Main Application Shell

  This is a code bundle for Main Application Shell. The original project is available at https://www.figma.com/design/KoC1PdEFrS3IoK4QgRnh1Q/Main-Application-Shell.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  